
# ERPNext related configs
ERPNEXT_API_KEY = 'd8ab58401ee92a7'
ERPNEXT_API_SECRET = '3e234bbf0b74934'
ERPNEXT_URL = 'https://hms.aakvaerp.com'


# operational configs
PULL_FREQUENCY = 60 # in minutes
LOGS_DIRECTORY = 'logs' # logs of this script is stored in this directory
IMPORT_START_DATE = None # format: '20190501'

